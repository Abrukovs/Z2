'use client';

import { useEffect, useState } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Target,
  Trophy,
  RefreshCw,
  Activity,
  BarChart3,
  Clock,
} from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface SportStat {
  sportKey: string;
  sport: string;
  icon: string;
  total: number;
  settled: number;
  won: number;
  lost: number;
  winRate: number;
  roi: number;
}

interface ConfidenceStat {
  confidence: string;
  total: number;
  settled: number;
  won: number;
  winRate: number;
  roi: number;
}

interface Stats {
  total: number;
  settled: number;
  pending: number;
  won: number;
  lost: number;
  push: number;
  noResult: number;
  winRate: number;
  totalStake: number;
  totalReturn: number;
  profit: number;
  roi: number;
  bySport: SportStat[];
  byConfidence: ConfidenceStat[];
}

const CONF_LABELS: Record<string, string> = {
  high: 'Высокая',
  medium: 'Средняя',
  low: 'Низкая',
};

const CONF_COLORS: Record<string, string> = {
  high: 'bg-emerald-100 text-emerald-700',
  medium: 'bg-amber-100 text-amber-700',
  low: 'bg-rose-100 text-rose-700',
};

export function StatsPanel() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchStats = async () => {
    setRefreshing(true);
    try {
      const res = await fetch('/api/stats', { cache: 'no-store' });
      const data = await res.json();
      if (data.success) {
        setStats(data);
      }
    } catch (e) {
      console.error('stats fetch error:', e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="p-4">
              <div className="h-4 w-16 animate-pulse rounded bg-slate-200" />
              <div className="mt-2 h-8 w-20 animate-pulse rounded bg-slate-200" />
            </Card>
          ))}
        </div>
        <Card className="p-6">
          <div className="h-32 animate-pulse rounded bg-slate-200" />
        </Card>
      </div>
    );
  }

  if (!stats) {
    return (
      <Card className="p-6 text-center text-slate-500">
        Не удалось загрузить статистику
      </Card>
    );
  }

  const profitPositive = stats.profit >= 0;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BarChart3 className="h-5 w-5 text-emerald-600" />
          <h2 className="text-lg font-extrabold tracking-tight text-slate-900">
            Статистика пиков
          </h2>
        </div>
        <Button
          onClick={fetchStats}
          disabled={refreshing}
          variant="outline"
          size="sm"
          className="gap-1.5"
        >
          <RefreshCw className={cn('h-4 w-4', refreshing && 'animate-spin')} />
          Обновить
        </Button>
      </div>

      {stats.total === 0 ? (
        <Card className="p-8 text-center">
          <Activity className="mx-auto h-10 w-10 text-slate-300" />
          <p className="mt-3 font-semibold text-slate-700">
            Пока нет пиков для статистики
          </p>
          <p className="mt-1 text-sm text-slate-500">
            Сгенерируйте пики на вкладке «Пики на сегодня» — статистика будет
            накапливаться автоматически. Результаты ЧМ/WNBA/MLB подтягиваются
            бесплатно из ESPN.
          </p>
        </Card>
      ) : (
        <>
          {/* Главные метрики */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <MetricCard
              icon={<Trophy className="h-4 w-4" />}
              label="Всего пиков"
              value={String(stats.total)}
              sub={`${stats.settled} рассчитано`}
              accent="emerald"
            />
            <MetricCard
              icon={<Target className="h-4 w-4" />}
              label="Винрейт"
              value={`${stats.winRate.toFixed(1)}%`}
              sub={`${stats.won}В / ${stats.lost}П`}
              accent="slate"
            />
            <MetricCard
              icon={
                profitPositive ? (
                  <TrendingUp className="h-4 w-4" />
                ) : (
                  <TrendingDown className="h-4 w-4" />
                )
              }
              label="Прибыль"
              value={`${profitPositive ? '+' : ''}${stats.profit.toFixed(2)}`}
              sub="ед. (по 1 ед./пик)"
              accent={profitPositive ? 'emerald' : 'rose'}
            />
            <MetricCard
              icon={
                profitPositive ? (
                  <TrendingUp className="h-4 w-4" />
                ) : (
                  <TrendingDown className="h-4 w-4" />
                )
              }
              label="ROI"
              value={`${stats.roi >= 0 ? '+' : ''}${stats.roi.toFixed(1)}%`}
              sub={`ставок: ${stats.totalStake}`}
              accent={profitPositive ? 'emerald' : 'rose'}
            />
          </div>

          {/* Pending / noResult */}
          {(stats.pending > 0 || stats.noResult > 0) && (
            <Card className="p-3.5">
              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500">
                {stats.pending > 0 && (
                  <span className="inline-flex items-center gap-1.5">
                    <Clock className="h-3.5 w-3.5 text-amber-500" />
                    Ожидают результата: <b className="text-slate-700">{stats.pending}</b>
                  </span>
                )}
                {stats.noResult > 0 && (
                  <span className="inline-flex items-center gap-1.5">
                    <Activity className="h-3.5 w-3.5 text-slate-400" />
                    Без авто-результата (теннис/кибер): <b className="text-slate-700">{stats.noResult}</b>
                  </span>
                )}
                {stats.push > 0 && (
                  <span className="inline-flex items-center gap-1.5">
                    Возвраты: <b className="text-slate-700">{stats.push}</b>
                  </span>
                )}
              </div>
            </Card>
          )}

          {/* По виду спорта */}
          {stats.bySport.length > 0 && (
            <Card className="p-4">
              <h3 className="mb-3 text-sm font-bold text-slate-900">
                По виду спорта
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-100 text-left text-xs uppercase tracking-wide text-slate-400">
                      <th className="pb-2 pr-2 font-semibold">Спорт</th>
                      <th className="pb-2 px-2 text-right font-semibold">Пиков</th>
                      <th className="pb-2 px-2 text-right font-semibold">Рассчитано</th>
                      <th className="pb-2 px-2 text-right font-semibold">Винрейт</th>
                      <th className="pb-2 pl-2 text-right font-semibold">ROI</th>
                    </tr>
                  </thead>
                  <tbody>
                    {stats.bySport.map((s) => (
                      <tr key={s.sportKey} className="border-b border-slate-50 last:border-0">
                        <td className="py-2.5 pr-2">
                          <span className="inline-flex items-center gap-2 font-medium text-slate-700">
                            <span className="text-base">{s.icon}</span>
                            {s.sport}
                          </span>
                        </td>
                        <td className="py-2.5 px-2 text-right tabular-nums text-slate-600">
                          {s.total}
                        </td>
                        <td className="py-2.5 px-2 text-right tabular-nums text-slate-600">
                          {s.settled}
                        </td>
                        <td className="py-2.5 px-2 text-right tabular-nums">
                          <span className={s.winRate >= 50 ? 'text-emerald-600 font-semibold' : 'text-slate-600'}>
                            {s.settled > 0 ? `${s.winRate.toFixed(0)}%` : '—'}
                          </span>
                        </td>
                        <td className="py-2.5 pl-2 text-right tabular-nums">
                          <span
                            className={cn(
                              'font-semibold',
                              s.roi > 0
                                ? 'text-emerald-600'
                                : s.roi < 0
                                  ? 'text-rose-600'
                                  : 'text-slate-500',
                            )}
                          >
                            {s.settled > 0 ? `${s.roi >= 0 ? '+' : ''}${s.roi.toFixed(1)}%` : '—'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          )}

          {/* По уровню уверенности */}
          {stats.byConfidence.some((c) => c.total > 0) && (
            <Card className="p-4">
              <h3 className="mb-3 text-sm font-bold text-slate-900">
                По уровню уверенности ИИ
              </h3>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                {stats.byConfidence.map((c) => (
                  <div
                    key={c.confidence}
                    className="rounded-lg border border-slate-100 bg-slate-50/50 p-3"
                  >
                    <div className="flex items-center justify-between">
                      <span
                        className={cn(
                          'rounded-full px-2 py-0.5 text-[11px] font-semibold',
                          CONF_COLORS[c.confidence],
                        )}
                      >
                        {CONF_LABELS[c.confidence]}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        {c.total} пик.
                      </span>
                    </div>
                    <div className="mt-2 flex items-end justify-between">
                      <div>
                        <p className="text-xs text-slate-500">Винрейт</p>
                        <p className="text-lg font-extrabold tabular-nums text-slate-900">
                          {c.settled > 0 ? `${c.winRate.toFixed(0)}%` : '—'}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-slate-500">ROI</p>
                        <p
                          className={cn(
                            'text-lg font-extrabold tabular-nums',
                            c.roi > 0
                              ? 'text-emerald-600'
                              : c.roi < 0
                                ? 'text-rose-600'
                                : 'text-slate-500',
                          )}
                        >
                          {c.settled > 0 ? `${c.roi >= 0 ? '+' : ''}${c.roi.toFixed(1)}%` : '—'}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}

          <p className="text-[11px] leading-relaxed text-slate-400">
            Статистика ведётся автоматически и бесплатно. Результаты матчей ЧМ,
            WNBA, MLB подтягиваются из ESPN API (без LLM-токенов). Пики по
            теннису и киберспорту помечаются «без авто-результата» — их можно
            учесть вручную позже. Расчёт условный: по 1 единице на каждый пик.
          </p>
        </>
      )}
    </div>
  );
}

function MetricCard({
  icon,
  label,
  value,
  sub,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub: string;
  accent: 'emerald' | 'rose' | 'amber' | 'slate';
}) {
  const accents: Record<string, { bg: string; text: string; value: string }> = {
    emerald: {
      bg: 'bg-emerald-50',
      text: 'text-emerald-600',
      value: 'text-emerald-700',
    },
    rose: { bg: 'bg-rose-50', text: 'text-rose-600', value: 'text-rose-700' },
    amber: { bg: 'bg-amber-50', text: 'text-amber-600', value: 'text-amber-700' },
    slate: { bg: 'bg-slate-100', text: 'text-slate-600', value: 'text-slate-900' },
  };
  const a = accents[accent];
  return (
    <Card className="p-3.5">
      <div className="flex items-center gap-2">
        <span className={cn('flex h-7 w-7 items-center justify-center rounded-lg', a.bg, a.text)}>
          {icon}
        </span>
        <span className="text-[11px] font-medium uppercase tracking-wide text-slate-400">
          {label}
        </span>
      </div>
      <p className={cn('mt-2 text-2xl font-extrabold tabular-nums', a.value)}>
        {value}
      </p>
      <p className="text-[11px] text-slate-400">{sub}</p>
    </Card>
  );
}
