'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, Clock, TrendingUp, AlertTriangle, Quote, ExternalLink } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { Pick, Confidence } from '@/lib/picks-service';
import { cn } from '@/lib/utils';

const CONF_STYLES: Record<
  Confidence,
  { label: string; badge: string; bar: string; dot: string; text: string }
> = {
  high: {
    label: 'Высокая',
    badge: 'bg-emerald-100 text-emerald-700 border-emerald-200',
    bar: 'bg-emerald-500',
    dot: 'bg-emerald-500',
    text: 'text-emerald-600',
  },
  medium: {
    label: 'Средняя',
    badge: 'bg-amber-100 text-amber-700 border-amber-200',
    bar: 'bg-amber-500',
    dot: 'bg-amber-500',
    text: 'text-amber-600',
  },
  low: {
    label: 'Низкая',
    badge: 'bg-rose-100 text-rose-700 border-rose-200',
    bar: 'bg-rose-500',
    dot: 'bg-rose-500',
    text: 'text-rose-600',
  },
};

export function PickCard({ pick }: { pick: Pick }) {
  const [open, setOpen] = useState(false);
  const conf = CONF_STYLES[pick.confidence];

  return (
    <Card className="group relative overflow-hidden p-0 shadow-sm transition-all hover:shadow-md">
      {/* Цветная полоска слева по виду спорта */}
      <div className="absolute inset-y-0 left-0 w-1.5 bg-gradient-to-b from-emerald-400 to-emerald-600" />

      <div className="p-5 pl-6">
        {/* Шапка: спорт + лига + время */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <span className="text-xl leading-none">{pick.sportIcon}</span>
            <Badge
              variant="secondary"
              className="truncate max-w-[140px] sm:max-w-[180px] font-medium"
            >
              {pick.league}
            </Badge>
            {pick.dataSource === 'ESPN API' && (
              <span
                className="shrink-0 inline-flex items-center gap-1 rounded-full bg-blue-50 px-2 py-0.5 text-[10px] font-semibold text-blue-700 ring-1 ring-inset ring-blue-200"
                title="Расписание подтверждено ESPN API"
              >
                <span className="h-1.5 w-1.5 rounded-full bg-blue-500" />
                ESPN
              </span>
            )}
          </div>
          {pick.startTime && (
            <span className="inline-flex items-center gap-1 text-xs font-medium text-slate-500 shrink-0">
              <Clock className="h-3.5 w-3.5" />
              {pick.startTime}
            </span>
          )}
        </div>

        {/* Команды */}
        <div className="mt-4 space-y-1">
          <p className="text-base font-semibold leading-snug text-slate-900">
            {pick.team1}
          </p>
          <p className="text-xs font-medium uppercase tracking-wide text-slate-400">
            против
          </p>
          <p className="text-base font-semibold leading-snug text-slate-900">
            {pick.team2}
          </p>
        </div>

        {/* Рекомендация */}
        <div className="mt-4 rounded-xl border border-emerald-100 bg-emerald-50/60 p-3">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-emerald-700/80">
                {pick.market}
              </p>
              <p className="mt-0.5 text-sm font-bold text-slate-900 break-words">
                {pick.selection}
              </p>
            </div>
            <div className="shrink-0 text-right">
              <p className="text-[10px] font-medium uppercase text-slate-400">
                Коэф.
              </p>
              <p className="text-lg font-extrabold tabular-nums text-emerald-700">
                {pick.odds}
              </p>
            </div>
          </div>
        </div>

        {/* Уверенность */}
        <div className="mt-4">
          <div className="flex items-center justify-between">
            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600">
              <TrendingUp className="h-3.5 w-3.5" />
              Уверенность
            </span>
            <Badge
              variant="outline"
              className={cn('text-[11px] font-semibold', conf.badge)}
            >
              <span className={cn('mr-1 h-1.5 w-1.5 rounded-full', conf.dot)} />
              {conf.label} · {pick.confidenceScore}%
            </Badge>
          </div>
          <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
            <motion.div
              className={cn('h-full rounded-full', conf.bar)}
              initial={{ width: 0 }}
              animate={{ width: `${pick.confidenceScore}%` }}
              transition={{ duration: 0.6, ease: 'easeOut' }}
            />
          </div>
        </div>

        {/* Раскрывающийся анализ */}
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="mt-4 flex w-full items-center justify-between rounded-lg px-1 py-1 text-left text-xs font-semibold text-slate-600 transition-colors hover:text-slate-900"
          aria-expanded={open}
        >
          <span>{open ? 'Скрыть анализ' : 'Показать анализ'}</span>
          <ChevronDown
            className={cn(
              'h-4 w-4 transition-transform',
              open && 'rotate-180',
            )}
          />
        </button>
        <AnimatePresence initial={false}>
          {open && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
              className="overflow-hidden"
            >
              <div className="space-y-2 pt-1 text-sm">
                {pick.reasoning && (
                  <p className="leading-relaxed text-slate-600">
                    {pick.reasoning}
                  </p>
                )}
                {pick.risk && (
                  <p className="flex items-start gap-1.5 rounded-md bg-amber-50 p-2 text-xs leading-relaxed text-amber-800">
                    <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                    <span>{pick.risk}</span>
                  </p>
                )}
                {pick.sourceQuote && (
                  <div className="rounded-md border border-slate-200 bg-slate-50/60 p-2.5">
                    <p className="mb-1 flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                      <Quote className="h-3 w-3" />
                      Источник
                    </p>
                    <p className="text-xs italic leading-relaxed text-slate-600">
                      «{pick.sourceQuote}»
                    </p>
                    {pick.sourceUrl && (
                      <a
                        href={pick.sourceUrl}
                        target="_blank"
                        rel="noopener noreferrer nofollow"
                        className="mt-1.5 inline-flex items-center gap-1 text-[11px] font-medium text-emerald-700 hover:text-emerald-800 hover:underline"
                      >
                        <ExternalLink className="h-3 w-3" />
                        {pick.sourceName || 'открыть источник'}
                      </a>
                    )}
                    {!pick.sourceUrl && pick.sourceName && (
                      <p className="mt-1.5 text-[11px] text-slate-400">
                        {pick.sourceName}
                      </p>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Card>
  );
}
