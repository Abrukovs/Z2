'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import {
  RefreshCw,
  Sparkles,
  CalendarDays,
  Target,
  Flame,
  Trophy,
  Inbox,
  AlertCircle,
  Activity,
  Search,
  Brain,
  Database,
  BarChart3,
  ListChecks,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Card } from '@/components/ui/card';
import { StatsPanel } from './stats-panel';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { PickCard } from './pick-card';
import type { Pick, Confidence } from '@/lib/picks-service';

interface UsageStats {
  webSearchCalls: number;
  llmCalls: number;
  totalCalls: number;
  cacheHits: number;
  generations: number;
  sessionStart: string;
  lastCallAt: string | null;
}

interface ApiResponse {
  success: boolean;
  date?: string;
  cached?: boolean;
  count: number;
  total: number;
  generatedAt?: string | null;
  picks: Pick[];
  error?: string;
  usage?: UsageStats;
  activeLeagues?: {
    football: string[];
    basketball: string[];
    tennis: string[];
    hockey: string[];
    esports: string[];
  };
  sportsSearched?: number;
  filteredOut?: number;
}

const SPORT_FILTERS: { key: string; label: string; icon: string }[] = [
  { key: 'all', label: 'Все', icon: '🏆' },
  { key: 'football', label: 'Футбол', icon: '⚽' },
  { key: 'basketball', label: 'Баскетбол', icon: '🏀' },
  { key: 'tennis', label: 'Теннис', icon: '🎾' },
  { key: 'hockey', label: 'Хоккей', icon: '🏒' },
  { key: 'esports', label: 'Киберспорт', icon: '🎮' },
  { key: 'volleyball', label: 'Волейбол', icon: '🏐' },
];

const CONF_FILTERS: { key: Confidence | 'all'; label: string }[] = [
  { key: 'all', label: 'Любая' },
  { key: 'high', label: 'Высокая' },
  { key: 'medium', label: 'Средняя' },
  { key: 'low', label: 'Низкая' },
];

function formatToday(): { pretty: string; weekday: string } {
  const now = new Date();
  return {
    pretty: now.toLocaleDateString('ru-RU', {
      day: 'numeric',
      month: 'long',
      timeZone: 'Europe/Moscow',
    }),
    weekday: now.toLocaleDateString('ru-RU', {
      weekday: 'long',
      timeZone: 'Europe/Moscow',
    }),
  };
}

export function PicksApp() {
  const [picks, setPicks] = useState<Pick[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [cached, setCached] = useState(false);
  const [generatedAt, setGeneratedAt] = useState<string | null>(null);
  const [usage, setUsage] = useState<UsageStats | null>(null);
  const [activeLeagues, setActiveLeagues] = useState<ApiResponse['activeLeagues'] | null>(null);
  const [sportsSearched, setSportsSearched] = useState<number | null>(null);
  const [filteredOut, setFilteredOut] = useState<number | null>(null);

  const [sportFilter, setSportFilter] = useState<string>('all');
  const [confFilter, setConfFilter] = useState<Confidence | 'all'>('all');
  const [activeTab, setActiveTab] = useState<'picks' | 'stats'>('picks');

  const { pretty, weekday } = useMemo(formatToday, []);

  const fetchPicks = useCallback(async (force: boolean) => {
    if (force) setRefreshing(true);
    else setLoading(true);
    setError(null);
    try {
      const url = `/api/picks?force=${force ? 1 : 0}`;
      const res = await fetch(url, { cache: 'no-store' });
      const data: ApiResponse = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Не удалось загрузить пики');
      }
      setPicks(data.picks);
      setCached(Boolean(data.cached));
      setGeneratedAt(data.generatedAt ?? null);
      if (data.usage) setUsage(data.usage);
      if (data.activeLeagues) setActiveLeagues(data.activeLeagues);
      setSportsSearched(data.sportsSearched ?? null);
      setFilteredOut(data.filteredOut ?? null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Ошибка загрузки');
      setPicks([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    fetchPicks(false);
  }, [fetchPicks]);

  // Клиентская фильтрация (дополнительно к серверной для мгновенной реакции)
  const visiblePicks = useMemo(() => {
    return picks.filter((p) => {
      if (sportFilter !== 'all' && p.sportKey !== sportFilter) return false;
      if (confFilter !== 'all' && p.confidence !== confFilter) return false;
      return true;
    });
  }, [picks, sportFilter, confFilter]);

  const stats = useMemo(() => {
    const total = picks.length;
    const high = picks.filter((p) => p.confidence === 'high').length;
    const sports = new Set(picks.map((p) => p.sportKey)).size;
    const avg =
      total > 0
        ? Math.round(
            picks.reduce((s, p) => s + p.confidenceScore, 0) / total,
          )
        : 0;
    return { total, high, sports, avg };
  }, [picks]);

  const generatedAtText = useMemo(() => {
    if (!generatedAt) return '';
    try {
      return new Date(generatedAt).toLocaleTimeString('ru-RU', {
        hour: '2-digit',
        minute: '2-digit',
        timeZone: 'Europe/Moscow',
      });
    } catch {
      return '';
    }
  }, [generatedAt]);

  return (
    <div className="flex flex-1 flex-col">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/85 backdrop-blur-md">
        <div className="mx-auto w-full max-w-6xl px-4 py-3 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-700 text-white shadow-sm">
                <Target className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <h1 className="truncate text-base font-extrabold tracking-tight text-slate-900 sm:text-lg">
                  Ставка Дня
                </h1>
                <p className="hidden text-[11px] text-slate-500 sm:block">
                  Ежедневные спортивные пики на основе ИИ
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              {/* Счётчик API-запросов */}
              {usage && usage.totalCalls > 0 && (
                <Popover>
                  <PopoverTrigger asChild>
                    <button
                      type="button"
                      className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-600 transition-colors hover:border-emerald-300 hover:text-emerald-700"
                      aria-label="Расход API-запросов"
                    >
                      <Activity className="h-3.5 w-3.5 text-emerald-600" />
                      <span className="tabular-nums">{usage.totalCalls}</span>
                      <span className="hidden sm:inline text-slate-400 font-normal">
                        запр.
                      </span>
                    </button>
                  </PopoverTrigger>
                  <PopoverContent className="w-72 p-4" align="end">
                    <UsagePanel
                      usage={usage}
                      activeLeagues={activeLeagues}
                      sportsSearched={sportsSearched}
                      filteredOut={filteredOut}
                    />
                  </PopoverContent>
                </Popover>
              )}
              <Button
                onClick={() => fetchPicks(true)}
                disabled={refreshing}
                variant="outline"
                size="sm"
                className="shrink-0 gap-1.5 border-slate-200"
              >
                <RefreshCw
                  className={cn('h-4 w-4', refreshing && 'animate-spin')}
                />
                <span className="hidden sm:inline">
                  {refreshing ? 'Обновление…' : 'Обновить'}
                </span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 w-full">
        <div className="mx-auto w-full max-w-6xl px-4 py-6 sm:px-6 sm:py-8 lg:px-8">
          {/* Переключатель вкладок */}
          <div className="mb-6 flex gap-1 rounded-xl bg-slate-100 p-1">
            <button
              type="button"
              onClick={() => setActiveTab('picks')}
              className={cn(
                'flex flex-1 items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold transition-all',
                activeTab === 'picks'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-500 hover:text-slate-700',
              )}
            >
              <ListChecks className="h-4 w-4" />
              Пики на сегодня
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('stats')}
              className={cn(
                'flex flex-1 items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold transition-all',
                activeTab === 'stats'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-500 hover:text-slate-700',
              )}
            >
              <BarChart3 className="h-4 w-4" />
              Статистика
            </button>
          </div>

          {activeTab === 'stats' ? (
            <StatsPanel />
          ) : (
            <>
          {/* Пики (2 колонки, слева) + Фильтры+Метрики (справа) — в один flex-row,
              чтобы верх пиков был на одной линии с верхом Select-ов */}
          <section className="mb-6">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
              {/* Пики — 2 колонки, слева */}
              <div className="min-w-0 flex-1">
                {loading ? (
                  <PicksSkeleton />
                ) : error ? (
                  <ErrorState error={error} onRetry={() => fetchPicks(false)} />
                ) : visiblePicks.length === 0 ? (
                  <EmptyState />
                ) : (
                  <motion.div
                    layout
                    className="grid grid-cols-1 gap-4 sm:grid-cols-2"
                  >
                    {visiblePicks.map((pick, i) => (
                      <motion.div
                        key={pick.id}
                        layout
                        initial={{ opacity: 0, y: 12 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: Math.min(i * 0.04, 0.4) }}
                      >
                        <PickCard pick={pick} />
                      </motion.div>
                    ))}
                  </motion.div>
                )}
              </div>

              {/* Правый блок: фильтры (без лейблов, чтобы верх = верх пиков) + метрики */}
              <div className="flex w-full flex-col gap-3 lg:w-auto lg:min-w-[260px]">
                {/* Фильтры — 2 компактных dropdown в ряд, БЕЗ лейблов сверху.
                    В trigger показываем название фильтра ('Вид спорта' / 'Надёжность'),
                    когда выбрано 'all'. Иначе — выбранное значение.
                    suppressHydrationWarning — подавляет ошибку гидратации Radix Select
                    (генерит случайные ID на сервере и клиенте). */}
                <div className="flex gap-2" suppressHydrationWarning>
                  <div className="min-w-[120px] flex-1">
                    <Select value={sportFilter} onValueChange={setSportFilter}>
                      <SelectTrigger className="w-full bg-white text-xs">
                        <SelectValue placeholder="Вид спорта">
                          {sportFilter === 'all'
                            ? 'Вид спорта'
                            : (() => {
                                const f = SPORT_FILTERS.find((s) => s.key === sportFilter);
                                return f ? `${f.icon} ${f.label}` : 'Вид спорта';
                              })()}
                        </SelectValue>
                      </SelectTrigger>
                      <SelectContent>
                        {SPORT_FILTERS.map((s) => (
                          <SelectItem key={s.key} value={s.key}>
                            <span className="mr-1.5">{s.icon}</span>
                            {s.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="min-w-[110px] flex-1">
                    <Select value={confFilter} onValueChange={(v) => setConfFilter(v as Confidence | 'all')}>
                      <SelectTrigger className="w-full bg-white text-xs">
                        <SelectValue placeholder="Надёжность">
                          {confFilter === 'all'
                            ? 'Надёжность'
                            : (() => {
                                const c = CONF_FILTERS.find((c) => c.key === confFilter);
                                return c ? c.label : 'Надёжность';
                              })()}
                        </SelectValue>
                      </SelectTrigger>
                      <SelectContent>
                        {CONF_FILTERS.map((c) => (
                          <SelectItem key={c.key} value={c.key}>
                            {c.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Метрики — компактный прямоугольник 2x2, ширина = фильтры */}
                {!loading && !error && picks.length > 0 && (
                  <Card className="overflow-hidden p-0 shadow-sm">
                    <div className="grid grid-cols-2 divide-x divide-y divide-slate-100">
                      <MetricItem
                        icon={<Inbox className="h-3.5 w-3.5" />}
                        label="Всего"
                        value={String(stats.total)}
                        accent="emerald"
                      />
                      <MetricItem
                        icon={<Flame className="h-3.5 w-3.5" />}
                        label="Выс.ув."
                        value={String(stats.high)}
                        accent="rose"
                      />
                      <MetricItem
                        icon={<Trophy className="h-3.5 w-3.5" />}
                        label="Видов"
                        value={String(stats.sports)}
                        accent="amber"
                      />
                      <MetricItem
                        icon={<Sparkles className="h-3.5 w-3.5" />}
                        label="Ср.ув."
                        value={`${stats.avg}%`}
                        accent="slate"
                      />
                    </div>
                  </Card>
                )}
              </div>
            </div>
          </section>

            {/* Описание внизу — дата, источник, время обновления */}
            {!loading && !error && (
              <section className="mt-6 flex flex-wrap items-center gap-2 text-xs text-slate-500">
                <CalendarDays className="h-3.5 w-3.5 text-emerald-600" />
                <span className="capitalize font-medium text-emerald-600">
                  {weekday}, {pretty}
                </span>
                <span className="text-slate-400">·</span>
                <span>
                  Отобранные ИИ спортивные события с рекомендациями для ставок
                </span>
                {generatedAtText && (
                  <>
                    <span className="text-slate-400">·</span>
                    <span className="text-slate-400">
                      обновлено в {generatedAtText}
                      {cached ? ' (из кэша)' : ''}
                    </span>
                  </>
                )}
              </section>
            )}
            </>
          )}
        </div>
      </main>
    </div>
  );
}

// Компактная метрика 2x2 в правом блоке (фильтры+метрики).
// Очень мелкий шрифт, метрики близко друг к другу, небольшой отступ от границ.
function MetricItem({
  icon,
  label,
  value,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  accent: 'emerald' | 'rose' | 'amber' | 'slate';
}) {
  const accents: Record<string, string> = {
    emerald: 'bg-emerald-50 text-emerald-600',
    rose: 'bg-rose-50 text-rose-600',
    amber: 'bg-amber-50 text-amber-600',
    slate: 'bg-slate-100 text-slate-600',
  };
  return (
    <div className="px-2.5 py-2">
      <div className="flex items-center gap-1">
        <span
          className={cn(
            'flex h-5 w-5 shrink-0 items-center justify-center rounded',
            accents[accent],
          )}
        >
          {icon}
        </span>
        <span className="text-[9px] font-semibold uppercase tracking-wide text-slate-400">
          {label}
        </span>
      </div>
      <p className="mt-1 text-base font-extrabold tabular-nums text-slate-900">
        {value}
      </p>
    </div>
  );
}

function PicksSkeleton() {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      {Array.from({ length: 4 }).map((_, i) => (
        <Card key={i} className="overflow-hidden p-5">
          <div className="flex items-center gap-2">
            <Skeleton className="h-6 w-6 rounded-full" />
            <Skeleton className="h-5 w-24 rounded-full" />
            <Skeleton className="ml-auto h-4 w-12" />
          </div>
          <div className="mt-4 space-y-2">
            <Skeleton className="h-5 w-3/4" />
            <Skeleton className="h-5 w-2/3" />
          </div>
          <Skeleton className="mt-4 h-16 w-full rounded-xl" />
          <Skeleton className="mt-4 h-4 w-full" />
          <Skeleton className="mt-3 h-3 w-1/2" />
        </Card>
      ))}
    </div>
  );
}

function EmptyState() {
  return (
    <Card className="flex flex-col items-center justify-center gap-3 py-16 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-full bg-slate-100">
        <Inbox className="h-7 w-7 text-slate-400" />
      </div>
      <div>
        <p className="font-semibold text-slate-700">Пиков не найдено</p>
        <p className="mt-1 text-sm text-slate-500">
          Попробуйте изменить фильтры или обновить подборку.
        </p>
      </div>
    </Card>
  );
}

function ErrorState({
  error,
  onRetry,
}: {
  error: string;
  onRetry: () => void;
}) {
  return (
    <Card className="flex flex-col items-center justify-center gap-4 py-16 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-full bg-rose-50">
        <AlertCircle className="h-7 w-7 text-rose-500" />
      </div>
      <div>
        <p className="font-semibold text-slate-700">Не удалось загрузить пики</p>
        <p className="mt-1 max-w-md text-sm text-slate-500">{error}</p>
      </div>
      <Button onClick={onRetry} className="gap-1.5">
        <RefreshCw className="h-4 w-4" />
        Повторить
      </Button>
    </Card>
  );
}

function UsagePanel({
  usage,
  activeLeagues,
  sportsSearched,
  filteredOut,
}: {
  usage: UsageStats;
  activeLeagues?: ApiResponse['activeLeagues'] | null;
  sportsSearched: number | null;
  filteredOut: number | null;
}) {
  const sessionDuration = useMemo(() => {
    try {
      const ms = Date.now() - new Date(usage.sessionStart).getTime();
      const min = Math.floor(ms / 60000);
      if (min < 1) return 'меньше минуты';
      if (min < 60) return `${min} мин`;
      const h = Math.floor(min / 60);
      return `${h} ч ${min % 60} мин`;
    } catch {
      return '—';
    }
  }, [usage.sessionStart]);

  const rows: { icon: React.ReactNode; label: string; value: string; color: string }[] = [
    {
      icon: <Search className="h-4 w-4" />,
      label: 'Веб-поиск',
      value: String(usage.webSearchCalls),
      color: 'text-emerald-600 bg-emerald-50',
    },
    {
      icon: <Brain className="h-4 w-4" />,
      label: 'LLM-анализ',
      value: String(usage.llmCalls),
      color: 'text-violet-600 bg-violet-50',
    },
    {
      icon: <Database className="h-4 w-4" />,
      label: 'Из кэша',
      value: String(usage.cacheHits),
      color: 'text-slate-600 bg-slate-100',
    },
  ];

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Activity className="h-4 w-4 text-emerald-600" />
          <p className="text-sm font-bold text-slate-900">Расход API</p>
        </div>
        <span className="text-[11px] text-slate-400">сессия: {sessionDuration}</span>
      </div>

      <div className="grid grid-cols-3 gap-2">
        {rows.map((r) => (
          <div key={r.label} className="rounded-lg border border-slate-100 bg-white p-2">
            <span
              className={cn(
                'inline-flex h-6 w-6 items-center justify-center rounded-md',
                r.color,
              )}
            >
              {r.icon}
            </span>
            <p className="mt-1.5 text-lg font-extrabold tabular-nums text-slate-900">
              {r.value}
            </p>
            <p className="text-[10px] uppercase tracking-wide text-slate-400">
              {r.label}
            </p>
          </div>
        ))}
      </div>

      <div className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2">
        <span className="text-xs font-medium text-slate-500">Всего запросов</span>
        <span className="text-sm font-extrabold tabular-nums text-slate-900">
          {usage.totalCalls}
        </span>
      </div>

      {activeLeagues && (
        <div className="space-y-1.5 border-t border-slate-100 pt-3">
          <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">
            Активные турниры (по сезону)
          </p>
          <div className="space-y-1 text-xs">
            {(
              [
                ['⚽ Футбол', activeLeagues.football],
                ['🏀 Баскетбол', activeLeagues.basketball],
                ['🎾 Теннис', activeLeagues.tennis],
                ['🏒 Хоккей', activeLeagues.hockey],
                ['🎮 Киберспорт', activeLeagues.esports],
              ] as [string, string[]][]
            ).map(([label, list]) => (
              <div key={label} className="flex items-start gap-2">
                <span className="shrink-0 font-medium text-slate-600">{label}</span>
                <span className="text-slate-500">
                  {list.length ? list.join(', ') : '— межсезонье'}
                </span>
              </div>
            ))}
          </div>
          {sportsSearched !== null && (
            <p className="text-[11px] text-slate-400">
              Поисковых запросов сегодня: {sportsSearched}
              {filteredOut !== null && filteredOut > 0 && (
                <span className="text-amber-600">
                  {' '}
                  · отсеяно не в сезоне: {filteredOut}
                </span>
              )}
            </p>
          )}
        </div>
      )}

      <p className="text-[11px] leading-relaxed text-slate-400">
        Счётчик накапливается за время работы сервера. Кэш (24 часа) и запросы
        из кэша не тарифицируются как новые вызовы веб-поиска и LLM.
      </p>
    </div>
  );
}
