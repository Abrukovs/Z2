import { ShieldAlert } from 'lucide-react';

export function SiteFooter() {
  return (
    <footer className="mt-auto border-t border-slate-200 bg-white">
      <div className="mx-auto w-full max-w-6xl px-4 py-6 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex items-start gap-3 max-w-3xl">
            <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-amber-500" />
            <p className="text-xs leading-relaxed text-slate-500">
              Информация носит исключительно ознакомительный характер и не является
              призывом к ставкам. Коэффициенты приблизительны и формируются на
              основе анализа открытых источников. Ставки на спорт связаны с
              финансовым риском — играйте ответственно. 18+.
            </p>
          </div>
          <div className="text-xs text-slate-400 shrink-0">
            <p>«Ставка Дня» · Powered by Z.ai</p>
            <p className="mt-1">Веб-поиск + LLM-анализ</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
