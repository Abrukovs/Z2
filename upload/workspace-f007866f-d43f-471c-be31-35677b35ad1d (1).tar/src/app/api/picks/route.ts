import { NextRequest, NextResponse } from 'next/server';
import { generateDailyPicks, type Pick } from '@/lib/picks-service';

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl;
  const sport = searchParams.get('sport') || 'all';
  const confidence = searchParams.get('confidence') || 'all';
  const force = searchParams.get('force') === '1';

  try {
    const {
      picks,
      cached,
      date,
      usage,
      activeLeagues,
      sportsSearched,
      filteredOut,
    } = await generateDailyPicks({ force });

    let filtered: Pick[] = picks;
    if (sport && sport !== 'all') {
      filtered = filtered.filter((p) => p.sportKey === sport);
    }
    if (confidence && confidence !== 'all') {
      filtered = filtered.filter((p) => p.confidence === confidence);
    }

    return NextResponse.json({
      success: true,
      date,
      cached,
      count: filtered.length,
      total: picks.length,
      generatedAt: picks[0]?.generatedAt ?? null,
      picks: filtered,
      // Метаданные расхода API
      usage,
      activeLeagues,
      sportsSearched,
      filteredOut,
    });
  } catch (error) {
    console.error('picks API error:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'unknown error',
        picks: [],
        count: 0,
      },
      { status: 500 },
    );
  }
}
