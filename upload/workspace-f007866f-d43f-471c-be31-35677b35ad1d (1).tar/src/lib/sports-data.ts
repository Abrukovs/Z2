// ====== TheSportsDB / ESPN — бесплатные источники расписания ======
// ESPN unofficial API: бесплатный, без ключа, отдаёт точные матчи дня в JSON.
// Используется для турниров, где веб-поиск даёт галлюцинации:
// ЧМ по футболу, WNBA, MLB. Для тенниса/киберспорта остаётся веб-поиск.

export interface SportsEvent {
  sportKey: string;       // football, basketball, baseball
  sportLabel: string;     // Футбол
  sportIcon: string;      // ⚽
  league: string;         // FIFA World Cup 2026
  team1: string;          // home team
  team2: string;          // away team
  startTimeMsk: string;   // HH:MM по Мск
  startTimeUtc: string;   // ISO UTC
  source: string;         // 'ESPN'
  sourceUrl: string;      // ссылка на матч (если есть)
  status: string;         // 'scheduled' | 'in-progress' | 'final'
}

// Кэш на 30 минут, чтобы не дёргать ESPN на каждый запрос
interface ApiCache {
  ts: number;
  data: SportsEvent[];
}
const apiCache = new Map<string, ApiCache>();
const API_CACHE_TTL = 30 * 60 * 1000;

// Маппинг sportKey → конфиг ESPN endpoint
const ESPN_SOURCES: {
  sportKey: string;
  sportLabel: string;
  sportIcon: string;
  leagueFilter?: string[]; // если задано — берём только эти лиги
  path: string;            // /sports/soccer/fifa.world
}[] = [
  {
    sportKey: 'football',
    sportLabel: 'Футбол',
    sportIcon: '⚽',
    path: 'soccer/fifa.world',
    leagueFilter: ['FIFA World Cup', 'World Cup', 'World Cup Qualifying'],
  },
  {
    sportKey: 'basketball',
    sportLabel: 'Баскетбол',
    sportIcon: '🏀',
    path: 'basketball/wnba',
  },
  {
    sportKey: 'baseball',
    sportLabel: 'Бейсбол',
    sportIcon: '⚾',
    path: 'baseball/mlb',
  },
];

// Конвертация UTC ISO → Мск HH:MM
function utcToMskHHMM(isoUtc: string): string {
  try {
    const d = new Date(isoUtc);
    if (isNaN(d.getTime())) return '';
    // Мск = UTC+3
    const msk = new Date(d.getTime() + 3 * 60 * 60 * 1000);
    const hh = String(msk.getUTCHours()).padStart(2, '0');
    const mm = String(msk.getUTCMinutes()).padStart(2, '0');
    return `${hh}:${mm}`;
  } catch {
    return '';
  }
}

function statusFromEspn(state: string): string {
  const s = (state || '').toLowerCase();
  if (s.includes('final') || s.includes('complete')) return 'final';
  // In-progress маркеры: конкретные слова, НЕ цифры (дата/время тоже содержит цифры)
  if (
    s.includes('in progress') ||
    s.includes('progress') ||
    s.includes('live') ||
    s.includes('q1') ||
    s.includes('q2') ||
    s.includes('q3') ||
    s.includes('q4') ||
    s.includes('halftime') ||
    s.includes('half-time') ||
    s.includes('1st period') ||
    s.includes('2nd period') ||
    s.includes('3rd period') ||
    /^\d{1,2}:\d{2}\s/.test(s) || // "12:34 2nd" — время в матче
    /^\d{1,2}-\d{1,2}/.test(s) // "3-2" — счёт в матче
  )
    return 'in-progress';
  return 'scheduled';
}

// Получить матчи дня по виду спорта из ESPN.
// В Next.js окружении fetch и node:https почему-то возвращают 400 от ESPN,
// хотя из bash curl работает. Используем child_process curl как fallback.
async function fetchEspnEvents(
  path: string,
  dateYmd: string,
): Promise<unknown[]> {
  const url = `https://site.api.espn.com/apis/site/v2/sports/${path}/scoreboard?dates=${dateYmd}`;
  const { exec } = await import('child_process');
  return new Promise<unknown[]>((resolve, reject) => {
    exec(
      `curl -s --compressed --max-time 15 -H "Accept: application/json" -H "User-Agent: Mozilla/5.0 (compatible; StavkaDnya/1.0)" "${url}"`,
      { encoding: 'utf8' },
      (err, stdout) => {
        if (err) {
          reject(err);
          return;
        }
        try {
          const data = JSON.parse(stdout) as { events?: unknown[] };
          resolve(data.events || []);
        } catch (e) {
          reject(e instanceof Error ? e : new Error(String(e)));
        }
      },
    );
  });
}

interface EspnEvent {
  name?: string;
  date?: string;
  status?: { type?: { detail?: string; state?: string } };
  competitions?: Array<{
    competitors?: Array<{
      homeAway?: string;
      team?: { displayName?: string; name?: string };
    }>;
    status?: { type?: { detail?: string; state?: string } };
  }>;
  league?: string;
}

// Главная функция: получить все события на дату по всем ESPN-источникам
export async function getTodayEventsFromApi(
  dateYmd: string,
): Promise<SportsEvent[]> {
  const cacheKey = `espn-${dateYmd}`;
  const cached = apiCache.get(cacheKey);
  if (cached && Date.now() - cached.ts < API_CACHE_TTL) {
    return cached.data;
  }

  const all: SportsEvent[] = [];

  for (const src of ESPN_SOURCES) {
    try {
      const events = await fetchEspnEvents(src.path, dateYmd);
      for (const eRaw of events) {
        const e = eRaw as EspnEvent;
        const comps = e.competitions || [];
        const comp = comps[0];
        if (!comp) continue;
        const competitors = comp.competitors || [];
        if (competitors.length < 2) continue;

        // homeAway определяет, кто home/away
        let home = '';
        let away = '';
        for (const c of competitors) {
          const name = c.team?.displayName || c.team?.name || '';
          if (c.homeAway === 'home') home = name;
          else if (c.homeAway === 'away') away = name;
        }
        if (!home || !away) continue;

        const statusRaw =
          comp.status?.type?.detail ||
          e.status?.type?.detail ||
          'scheduled';
        const status = statusFromEspn(statusRaw);

        const isoUtc = e.date || '';
        const startTimeMsk = utcToMskHHMM(isoUtc);

        all.push({
          sportKey: src.sportKey,
          sportLabel: src.sportLabel,
          sportIcon: src.sportIcon,
          league: src.leagueFilter
            ? // для ЧМ: имя лиги берём из leagueFilter[0] для удобства
              src.leagueFilter[0] === 'FIFA World Cup'
              ? 'Чемпионат мира по футболу'
              : src.sportLabel
            : src.sportLabel === 'Баскетбол'
              ? 'WNBA'
              : src.sportLabel === 'Бейсбол'
                ? 'MLB'
                : src.sportLabel,
          team1: home,
          team2: away,
          startTimeMsk,
          startTimeUtc: isoUtc,
          source: 'ESPN',
          sourceUrl: 'https://www.espn.com/',
          status,
        });
      }
    } catch (err) {
      console.error(`[sports-data] ESPN fetch failed for ${src.path}:`, err);
    }
    // Логируем сколько получили из каждого источника
    const gotCount = all.filter(
      (a) => a.sportKey === src.sportKey,
    ).length;
    console.log(`[sports-data] ESPN ${src.path}: ${gotCount} events parsed`);
    // Пауза между источниками
    await new Promise((r) => setTimeout(r, 300));
  }

  // Кэшируем только если есть данные (чтобы не кэшировать ошибки)
  if (all.length > 0) {
    apiCache.set(cacheKey, { ts: Date.now(), data: all });
  }
  return all;
}

// Фильтр: оставить только предстоящие (scheduled) и не начавшиеся по Мск.
// ВАЖНО: сравниваем полную дату+время UTC, а не только HH:MM. Иначе матч
// в 01:40 МСК (ночь следующего дня) при текущем времени 13:51 МСК будет
// ложно отбракован как «прошедший».
export function filterUpcoming(
  events: SportsEvent[],
  currentTimeMsk: string,
): SportsEvent[] {
  // Текущее время в UTC (для сравнения с startTimeUtc)
  const nowUtc = Date.now();
  // Буфер 30 минут
  const bufferMs = 30 * 60 * 1000;
  return events.filter((e) => {
    if (e.status === 'final' || e.status === 'in-progress') return false;
    if (e.startTimeUtc) {
      const startUtc = Date.parse(e.startTimeUtc);
      if (!isNaN(startUtc)) {
        // Если матч уже начался (с буфером 30 мин) — отбраковываем
        if (startUtc + bufferMs < nowUtc) return false;
      }
    }
    return true;
  });
}
