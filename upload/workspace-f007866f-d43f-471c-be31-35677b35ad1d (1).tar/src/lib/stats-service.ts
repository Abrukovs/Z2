// ====== Статистика пиков (без расхода LLM-токенов) ======
// Пики сохраняются в SQLite. Результаты подтягиваются из бесплатного ESPN API
// (для ЧМ/WNBA/MLB). Считаем ROI, win rate, прибыль — локально, бесплатно.

import { db } from '@/lib/db';
import type { Pick } from './picks-service';
import {
  getTodayEventsFromApi,
  type SportsEvent,
} from './sports-data';

export type PickResult = 'pending' | 'won' | 'lost' | 'push' | 'no_result';

export interface Stats {
  total: number;
  settled: number;     // с известным результатом (won + lost + push)
  pending: number;     // ожидают результата
  won: number;
  lost: number;
  push: number;
  noResult: number;    // нет авто-результата (теннис/киберспорт без ESPN)
  winRate: number;     // won / settled * 100
  totalStake: number;  // по 1 ед. на каждый settled пик
  totalReturn: number; // возврат (odds * 1 для won, 0 для lost, 1 для push)
  profit: number;      // totalReturn - totalStake
  roi: number;         // profit / totalStake * 100
  bySport: SportStat[];
  byConfidence: ConfidenceStat[];
}

export interface SportStat {
  sportKey: string;
  sport: string;
  icon: string;
  total: number;
  settled: number;
  won: number;
  lost: number;
  winRate: number;
  roi: number;
}

export interface ConfidenceStat {
  confidence: string;
  total: number;
  settled: number;
  won: number;
  winRate: number;
  roi: number;
}

// Сохранить свежесгенерированные пики в БД (без дубликатов по id)
export async function savePicksToDb(picks: Pick[], pickDate: string) {
  if (!picks.length) return;
  try {
    const data = picks.map((p) => ({
      id: p.id,
      sportKey: p.sportKey,
      sport: p.sport,
      league: p.league,
      team1: p.team1,
      team2: p.team2,
      startTime: p.startTime,
      market: p.market,
      selection: p.selection,
      odds: p.odds,
      confidence: p.confidence,
      confidenceScore: p.confidenceScore,
      dataSource: p.dataSource,
      pickDate,
    }));
    // upsert — если пик уже есть (по id), не перезаписываем результат
    for (const d of data) {
      await db.storedPick.upsert({
        where: { id: d.id },
        create: d,
        update: {}, // не трогаем существующие (включая result)
      });
    }
  } catch (e) {
    console.error('[stats] savePicksToDb failed:', e);
  }
}

interface EspnEventWithScore {
  name?: string;
  date?: string;
  competitions?: Array<{
    competitors?: Array<{
      homeAway?: string;
      score?: string;
      team?: { displayName?: string };
    }>;
    status?: { type?: { completed?: boolean; detail?: string } };
  }>;
}

// Получить результаты завершённых матчей из ESPN по всем источникам
async function fetchEspnResults(
  dateYmd: string,
): Promise<{ home: string; away: string; homeScore: number; awayScore: number }[]> {
  const sources = [
    'soccer/fifa.world',
    'basketball/wnba',
    'baseball/mlb',
  ];
  const results: {
    home: string;
    away: string;
    homeScore: number;
    awayScore: number;
  }[] = [];
  const { exec } = await import('child_process');

  for (const path of sources) {
    const url = `https://site.api.espn.com/apis/site/v2/sports/${path}/scoreboard?dates=${dateYmd}`;
    await new Promise<void>((resolve) => {
      exec(
        `curl -s --compressed --max-time 15 -H "Accept: application/json" -H "User-Agent: Mozilla/5.0 (compatible; StavkaDnya/1.0)" "${url}"`,
        { encoding: 'utf8' },
        (err, stdout) => {
          if (err) {
            console.error(`[stats] ESPN curl failed for ${path} ${dateYmd}:`, err.message);
            resolve();
            return;
          }
          try {
            const data = JSON.parse(stdout) as { events?: EspnEventWithScore[]; code?: number };
            if (data.code) {
              console.error(`[stats] ESPN API error for ${path} ${dateYmd}:`, stdout.slice(0, 100));
              resolve();
              return;
            }
            for (const e of data.events || []) {
              const comp = e.competitions?.[0];
              if (!comp?.competitors || comp.competitors.length < 2) continue;
              // Считаем матч завершённым, если у обеих команд есть счёт > -1.
              // Раньше проверяли status.completed === true, но для ЧМ ESPN
              // иногда не ставит completed, хотя счёт уже есть.
              let home = '';
              let away = '';
              let homeScore: number | null = null;
              let awayScore: number | null = null;
              for (const c of comp.competitors) {
                const scoreStr = c.score;
                const score = scoreStr != null ? parseInt(scoreStr, 10) : NaN;
                if (c.homeAway === 'home') {
                  home = c.team?.displayName || '';
                  homeScore = score;
                } else if (c.homeAway === 'away') {
                  away = c.team?.displayName || '';
                  awayScore = score;
                }
              }
              if (
                home &&
                away &&
                homeScore !== null &&
                awayScore !== null &&
                !isNaN(homeScore) &&
                !isNaN(awayScore)
              ) {
                results.push({ home, away, homeScore, awayScore });
              }
            }
          } catch {
            // ignore parse error
          }
          resolve();
        },
      );
    });
    await new Promise((r) => setTimeout(r, 200));
  }
  return results;
}

// Нормализация имени для сравнения (без регистра, пробелов, спецсимволов)
function normName(s: string): string {
  return (s || '')
    .toLowerCase()
    .replace(/[^a-zа-яё0-9]/gi, '')
    .trim();
}

// Словарь рус→англ для сборных (ESPN отдаёт английские названия)
const NATIONAL_TEAM_RU_EN: Record<string, string> = {
  канада: 'canada',
  марокко: 'morocco',
  сша: 'unitedstates',
  америка: 'unitedstates',
  аргентина: 'argentina',
  бразилия: 'brazil',
  франция: 'france',
  германия: 'germany',
  испания: 'spain',
  португалия: 'portugal',
  италия: 'italy',
  англия: 'england',
  нидерланды: 'netherlands',
  голландия: 'netherlands',
  бельгия: 'belgium',
  хорватия: 'croatia',
  сербия: 'serbia',
  швейцария: 'switzerland',
  польша: 'poland',
  мексика: 'mexico',
  уругвай: 'uruguay',
  колумбия: 'colombia',
  перу: 'peru',
  чили: 'chile',
  эквадор: 'ecuador',
  япония: 'japan',
  южнаякорея: 'southkorea',
  корея: 'southkorea',
  австралия: 'australia',
  иран: 'iran',
  саудовскаяаравия: 'saudiarabia',
  катар: 'qatar',
  египет: 'egypt',
  сенегал: 'senegal',
  гана: 'ghana',
  нигерия: 'nigeria',
  камерун: 'cameroon',
  тунис: 'tunisia',
  марокко: 'morocco',
  алжир: 'algeria',
  кабо_верде: 'capeverde',
  кабоверде: 'capeverde',
  парагвай: 'paraguay',
  боливия: 'bolivia',
  венесуэла: 'venezuela',
  костарика: 'costarica',
  панама: 'panama',
  гондурас: 'honduras',
  сальвадор: 'elsalvador',
  ямайка: 'jamaica',
  исландия: 'iceland',
  швеция: 'sweden',
  норвегия: 'norway',
  дания: 'denmark',
  финляндия: 'finland',
  ирландия: 'ireland',
  шотландия: 'scotland',
  уэльс: 'wales',
  россия: 'russia',
  украина: 'ukraine',
  турция: 'turkey',
  греция: 'greece',
  румыния: 'romania',
  венгрия: 'hungary',
  чехия: 'czechrepublic',
  словакия: 'slovakia',
  словения: 'slovenia',
  австрия: 'austria',
  грузия: 'georgia',
};

// Нормализация имени с учётом рус→англ словаря
function normNameWithDict(s: string): string {
  const ru = s.toLowerCase().replace(/[^а-яё]/gi, '').trim();
  if (ru && NATIONAL_TEAM_RU_EN[ru]) {
    return NATIONAL_TEAM_RU_EN[ru];
  }
  return normName(s);
}

// Найти результат матча в ESPN-данных по именам команд
function findResult(
  espnResults: { home: string; away: string; homeScore: number; awayScore: number }[],
  team1: string,
  team2: string,
) {
  const t1 = normNameWithDict(team1);
  const t2 = normNameWithDict(team2);
  return espnResults.find((r) => {
    const h = normNameWithDict(r.home);
    const a = normNameWithDict(r.away);
    const matchDirect =
      (h.includes(t1.slice(0, 5)) || t1.includes(h.slice(0, 5))) &&
      (a.includes(t2.slice(0, 5)) || t2.includes(a.slice(0, 5)));
    const matchSwap =
      (a.includes(t1.slice(0, 5)) || t1.includes(a.slice(0, 5))) &&
      (h.includes(t2.slice(0, 5)) || t2.includes(h.slice(0, 5)));
    return matchDirect || matchSwap;
  });
}

// Определить результат пика по счёту и рынку.
// Поддерживаем базовые рынки: Победа 1 / Победа 2 / Победа X (ничья).
// Для тоталов/фор/сложных рынков — возвращаем 'no_result' (пользователь сам разметит).
function resolvePick(
  pick: {
    market: string;
    selection: string;
    team1: string;
    team2: string;
  },
  homeScore: number,
  awayScore: number,
  // какой команде соответствует team1: 'home' | 'away' | 'unknown'
  team1Side: 'home' | 'away' | 'unknown',
): PickResult {
  const m = (pick.market || '').toLowerCase();
  const sel = (pick.selection || '').toLowerCase();
  const t1lower = (pick.team1 || '').toLowerCase();
  const t2lower = (pick.team2 || '').toLowerCase();
  // Объединяем market + selection для поиска числа (тотал может быть в selection)
  const combined = `${pick.market || ''} ${pick.selection || ''}`;
  const combinedLower = combined.toLowerCase();

  // Победа команды 1: П1, Победа 1, Победа матча/Победитель/Moneyline (если selection = team1)
  const selHasTeam1 = t1lower.split(/\s+/).some((part) => part.length >= 4 && sel.includes(part));
  const selHasTeam2 = t2lower.split(/\s+/).some((part) => part.length >= 4 && sel.includes(part));
  const isMoneylineOrWin =
    m.includes('победа') ||
    m.includes('победитель') ||
    m.includes('moneyline') ||
    m.includes('ml') ||
    m.includes('исход') ||
    m.includes('to win') ||
    m.includes('winner');
  const isWin1 = isMoneylineOrWin && selHasTeam1 && !selHasTeam2;
  const isWin2 = isMoneylineOrWin && selHasTeam2 && !selHasTeam1;
  // Явные П1/П2 (когда selection тоже может содержать обе команды)
  const isWin1Explicit = m.includes('победа 1') || m.includes('п1');
  const isWin2Explicit = m.includes('победа 2') || m.includes('п2');

  // Ничья
  const isDraw = m.includes('ничья') || m.includes('draw') || (m.includes('х') && m.length <= 5);

  if (isWin1 || isWin2 || isWin1Explicit || isWin2Explicit) {
    const t1Score = team1Side === 'home' ? homeScore : awayScore;
    const t2Score = team1Side === 'home' ? awayScore : homeScore;
    // Защита от ложного 0:0 (ESPN не отдал счёт, но статус был completed).
    // В баскетболе/бейсболе/теннисе 0:0 невозможно — значит данных нет.
    if (t1Score === 0 && t2Score === 0) return 'no_result';
    const win1 = isWin1 || isWin1Explicit;
    if (t1Score > t2Score) return win1 ? 'won' : 'lost';
    if (t1Score < t2Score) return win1 ? 'lost' : 'won';
    return 'push'; // ничья в матче без ничьей в рынке — возврат
  }
  if (isDraw) {
    return homeScore === awayScore ? 'won' : 'lost';
  }
  // Фора (handicap): "Фора (-1.5)" или "Фора 1(-1.5)" или "Cardinals -1.5"
  // Парсим знак и число форы, определяем команду.
  const isHandicap = combinedLower.includes('фора') || combinedLower.includes('handicap') ||
    (/\(-?\d+\.?\d*\)/.test(combinedLower) && !combinedLower.includes('тотал'));
  if (isHandicap) {
    // Парсим линию форы: (-1.5) или -1.5 или 1(-1.5)
    const lineMatch = combinedLower.match(/\(?(-?\d+\.?\d*)\)?/);
    if (!lineMatch) return 'no_result';
    const line = parseFloat(lineMatch[1]);
    // Определяем команду: selection содержит имя команды, или "1"/"2"
    const isTeam1 = selHasTeam1 || combinedLower.includes('фора 1') || combinedLower.includes('cardinals') && t1lower.includes('cardinals');
    const isTeam2 = selHasTeam2 || combinedLower.includes('фора 2');
    if (!isTeam1 && !isTeam2) return 'no_result';
    const t1Score = team1Side === 'home' ? homeScore : awayScore;
    const t2Score = team1Side === 'home' ? awayScore : homeScore;
    if (t1Score === 0 && t2Score === 0) return 'no_result';
    // Применяем фору: если line отрицательная (-1.5), прибавляем к счёту команды
    if (isTeam1) {
      const adjusted = t1Score + line;
      if (adjusted > t2Score) return 'won';
      if (adjusted < t2Score) return 'lost';
      return 'push';
    } else {
      const adjusted = t2Score + line;
      if (adjusted > t1Score) return 'won';
      if (adjusted < t1Score) return 'lost';
      return 'push';
    }
  }

  // Тотал больше/меньше — парсим число из combined (market + selection)
  const tbMatch = combinedLower.match(/тотал\s*(?:больше|более|>|over)/i) || combinedLower.match(/over\s*\/?under.*over/i);
  const tmMatch = combinedLower.match(/тотал\s*(?:меньше|менее|<|under)/i) || combinedLower.match(/over\s*\/?under.*under/i);
  // Also English: "over 8.5", "under 7.5"
  const overEn = combinedLower.match(/\bover\b/);
  const underEn = combinedLower.match(/\bunder\b/);
  const numMatch = combinedLower.match(/(\d+\.?\d*)/);
  if ((tbMatch || overEn || tmMatch || underEn) && numMatch) {
    const line = parseFloat(numMatch[1]);
    const total = homeScore + awayScore;
    if (tbMatch || overEn) {
      if (total > line) return 'won';
      if (total < line) return 'lost';
      return 'push';
    }
    if (tmMatch || underEn) {
      if (total < line) return 'won';
      if (total > line) return 'lost';
      return 'push';
    }
  }
  return 'no_result';
}

// Главная функция: проверить и обновить результаты для всех pending пиков.
// Запускается при запросе /api/stats. Бесплатно (ESPN без токенов).
export async function updatePendingResults(): Promise<{
  checked: number;
  updated: number;
}> {
  let checked = 0;
  let updated = 0;
  try {
    // Берём все pending пики (не только ESPN — ЧМ-пики из веб-поиска тоже
    // можно проверить через ESPN, т.к. ESPN покрывает ЧМ).
    // Исключаем только теннис и киберспорт (ESPN их не покрывает детально).
    const pending = await db.storedPick.findMany({
      where: {
        result: 'pending',
        sportKey: { in: ['football', 'basketball', 'baseball'] },
      },
      take: 100,
    });
    if (!pending.length) return { checked: 0, updated: 0 };

    // Группируем по pickDate
    const byDate = new Map<string, typeof pending>();
    for (const p of pending) {
      const arr = byDate.get(p.pickDate) || [];
      arr.push(p);
      byDate.set(p.pickDate, arr);
    }

    for (const [date, picks] of byDate) {
      const dateEspn = date.replace(/-/g, '');
      const espnResults = await fetchEspnResults(dateEspn);
      checked += picks.length;
      for (const p of picks) {
        const r = findResult(espnResults, p.team1, p.team2);
        if (!r) continue;
        // Определяем, кто home/away в нашем пике
        const t1 = normNameWithDict(p.team1);
        const h = normNameWithDict(r.home);
        const team1Side: 'home' | 'away' | 'unknown' = h.includes(t1.slice(0, 5))
          ? 'home'
          : 'away';
        const res = resolvePick(p, r.homeScore, r.awayScore, team1Side);
        if (res === 'no_result') continue;
        await db.storedPick.update({
          where: { id: p.id },
          data: {
            result: res,
            homeScore: team1Side === 'home' ? r.homeScore : r.awayScore,
            awayScore: team1Side === 'home' ? r.awayScore : r.homeScore,
            resultCheckedAt: new Date(),
          },
        });
        updated += 1;
      }
    }
  } catch (e) {
    console.error('[stats] updatePendingResults failed:', e);
  }

  // ====== АВТО-NO_RESULT для неподдерживаемых видов спорта и ненайденных ======
  // 1. Теннис, киберспорт, хоккей — ESPN не покрывает детально.
  // 2. Баскетбол без WNBA (Летняя лига НБА и т.д.) — тоже не покрывает.
  // 3. Пики за прошлые дни (вчера и раньше), не найденные в ESPN — помечаем
  //    no_result, так как ESPN уже должен был отдать результат. Если не отдал —
  //    матч отменён или ESPN не покрывает этот турнир.
  try {
    const yesterday = new Date(Date.now() - 1 * 24 * 60 * 60 * 1000)
      .toISOString()
      .slice(0, 10);
    const stillPending = await db.storedPick.findMany({
      where: {
        result: 'pending',
        OR: [
          // Теннис, киберспорт, хоккей — ESPN не покрывает
          { sportKey: { in: ['tennis', 'esports', 'hockey', 'volleyball'] } },
          // Баскетбол, но не WNBA
          {
            sportKey: 'basketball',
            league: { not: { contains: 'WNBA' } },
          },
          // Вчерашние и старше пики (ESPN уже должен был отдать результат)
          { pickDate: { lt: yesterday } },
        ],
      },
    });
    for (const p of stillPending) {
      await db.storedPick.update({
        where: { id: p.id },
        data: { result: 'no_result', resultCheckedAt: new Date() },
      });
      updated += 1;
    }
    if (stillPending.length > 0) {
      console.log(
        `[stats] auto no_result: ${stillPending.length} picks (unsupported or stale)`,
      );
    }
  } catch (e) {
    console.error('[stats] auto no_result failed:', e);
  }

  return { checked, updated };
}

const SPORT_ICONS: Record<string, string> = {
  football: '⚽',
  basketball: '🏀',
  tennis: '🎾',
  hockey: '🏒',
  esports: '🎮',
  baseball: '⚾',
  volleyball: '🏐',
};

// Посчитать итоговую статистику из БД
export async function computeStats(): Promise<Stats> {
  const all = await db.storedPick.findMany({ orderBy: { createdAt: 'asc' } });

  const total = all.length;
  const won = all.filter((p) => p.result === 'won').length;
  const lost = all.filter((p) => p.result === 'lost').length;
  const push = all.filter((p) => p.result === 'push').length;
  const noResult = all.filter((p) => p.result === 'no_result').length;
  const pending = all.filter((p) => p.result === 'pending').length;
  const settled = won + lost + push;

  // Финансы: по 1 ед. на каждый settled
  let totalStake = 0;
  let totalReturn = 0;
  for (const p of all) {
    if (p.result === 'won') {
      totalStake += 1;
      const odds = parseFloat(p.odds.replace(',', '.'));
      totalReturn += isFinite(odds) ? odds : 1;
    } else if (p.result === 'lost') {
      totalStake += 1;
      // return = 0
    } else if (p.result === 'push') {
      totalStake += 1;
      totalReturn += 1; // возврат
    }
  }
  const profit = totalReturn - totalStake;
  const roi = totalStake > 0 ? (profit / totalStake) * 100 : 0;
  const winRate = settled > 0 ? (won / settled) * 100 : 0;

  // По виду спорта
  const sportKeys = [...new Set(all.map((p) => p.sportKey))];
  const bySport: SportStat[] = sportKeys.map((key) => {
    const items = all.filter((p) => p.sportKey === key);
    const sw = items.filter((p) => p.result === 'won').length;
    const sl = items.filter((p) => p.result === 'lost').length;
    const sp = items.filter((p) => p.result === 'push').length;
    const sSettled = sw + sl + sp;
    let stake = 0;
    let ret = 0;
    for (const p of items) {
      if (p.result === 'won') {
        stake += 1;
        const odds = parseFloat(p.odds.replace(',', '.'));
        ret += isFinite(odds) ? odds : 1;
      } else if (p.result === 'lost') {
        stake += 1;
      } else if (p.result === 'push') {
        stake += 1;
        ret += 1;
      }
    }
    const p = ret - stake;
    return {
      sportKey: key,
      sport: items[0]?.sport || key,
      icon: SPORT_ICONS[key] || '🏆',
      total: items.length,
      settled: sSettled,
      won: sw,
      lost: sl,
      winRate: sSettled > 0 ? (sw / sSettled) * 100 : 0,
      roi: stake > 0 ? (p / stake) * 100 : 0,
    };
  });

  // По уверенности
  const confKeys = ['high', 'medium', 'low'];
  const byConfidence: ConfidenceStat[] = confKeys.map((c) => {
    const items = all.filter((p) => p.confidence === c);
    const sw = items.filter((p) => p.result === 'won').length;
    const sl = items.filter((p) => p.result === 'lost').length;
    const sp = items.filter((p) => p.result === 'push').length;
    const sSettled = sw + sl + sp;
    let stake = 0;
    let ret = 0;
    for (const p of items) {
      if (p.result === 'won') {
        stake += 1;
        const odds = parseFloat(p.odds.replace(',', '.'));
        ret += isFinite(odds) ? odds : 1;
      } else if (p.result === 'lost') {
        stake += 1;
      } else if (p.result === 'push') {
        stake += 1;
        ret += 1;
      }
    }
    const p = ret - stake;
    return {
      confidence: c,
      total: items.length,
      settled: sSettled,
      won: sw,
      winRate: sSettled > 0 ? (sw / sSettled) * 100 : 0,
      roi: stake > 0 ? (p / stake) * 100 : 0,
    };
  });

  return {
    total,
    settled,
    pending,
    won,
    lost,
    push,
    noResult,
    winRate,
    totalStake,
    totalReturn: Math.round(totalReturn * 100) / 100,
    profit: Math.round(profit * 100) / 100,
    roi: Math.round(roi * 100) / 100,
    bySport,
    byConfidence,
  };
}
